var telaLiberada = 1;
var arrMenu = [];
for(var m in arrTela){
	if(typeof arrTela[m].menu == "undefined"){ continue; } 
	if(typeof arrMenu[arrTela[m].menu] !== "undefined"){ continue; }
	arrMenu[arrTela[m].menu] = {tela:parseInt(m)+1,titulo:arrTela[m].titulo};
}
var strMenu = '<nav id="menucurso"><ol>';
for(var m in arrMenu){ strMenu += '<li data-tela="'+arrMenu[m].tela+'" class="desabilitado">'+arrMenu[m].titulo+'</li>'; }
strMenu += '</ol></nav>';

var popupDialog;
var objAlerta = objAlertaPadrao = { modal:true,closeText:'Fechar',closeOnEscape:false,title:'Alerta',width:'auto',dialogClass:'',
	position:{my:"center",at:"center",of:window,collision:"none"},
	open:function(){ 
		var somModal = $(this).find('audio.sominterno');
		if(somModal.length>0){ stopPlay(somModal); }
		if($(popupDialog).data("ui-dialog")){ $(popupDialog).dialog('destroy'); } 
	},
	close:function(event,ui){ 
		$(this).dialog('destroy');
		objAlerta = objAlertaPadrao;
	},
	buttons:[{text:"OK",click:function(){$(this).dialog('close'); }}],
	show:{effect:'fade',duration:500},hide:{effect:'explode',duration:250}
};

function stopPlay(audio){
	$('audio').each(function(i){ $(this)[0].currentTime = 0; $(this)[0].pause(); });
	if(typeof(audio)==="undefined"){ return; }
	if((audio.length>0)){ $(audio)[0].play(); }
}

/*
	Chamada: janelaModal('Titulo do Modal','nada, topo ou rodape','nada,auto,grande,pequeno','<div>conteudo(audio) entre divs sempre</div>',0,function(){ qualquerfuncao(); });
	bloqueado: 0 = Modal com botão fechar; 1000 = botão fechar aparece depois de 1segundo
	acao: função que é executada ao fechar o Modal
*/
function janelaModal(titulo,posicao,classe,conteudo,bloqueado,acao){
	bloqueado = (typeof(bloqueado)=="undefined")?0:parseInt(bloqueado); //tempo de bloqueio dos botões
	objAlerta.title = titulo;
	objAlerta.width = '60vw';
	objAlerta.height = 'auto';
	if(screen.width<768){ 
		objAlerta.width = 'auto';
		posicao = 'rodape'; 
	}
	
	if(classe.search('grande')>-1){ objAlerta.width = '90vw'; } 
	else if(classe.search('pequeno')>-1){ objAlerta.width = '50vw'; }
	else if(classe.search('auto')>-1){ objAlerta.width = 'auto'; }

	switch(posicao){
		case 'topo': objAlerta.position = {my:"center top",at:"center top+150",of:window,collision:"none"}; break;
		case 'rodape': objAlerta.position = {my:"center bottom",at:"center bottom-100",of:window,collision:"none"}; break;
		default: objAlerta.position = {my:"center",at:"center",of:window,collision:"none"}; break;
	}
	
	if(bloqueado>0){ classe += ' semfechar'; }
	objAlerta.dialogClass = classe;
		
	//Acao ao fechar o modal
	if((typeof(acao)=="function")){
		objAlerta.close = function(event,ui){ 
			$(this).dialog('destroy');
			objAlerta = objAlertaPadrao;
			acao();
		}
	} else {
		objAlerta.close = function(event,ui){ 
			$(this).dialog('destroy');
			objAlerta = objAlertaPadrao;
		}
	}
	
	popupDialog = $(conteudo).dialog(objAlerta);
	if(bloqueado>0){ setTimeout(function(){ $('.semfechar').removeClass('semfechar'); },bloqueado); }

}

function interacao_sanfona(primeirofechado){ //interacao_sanfona(false) = primeiro item aberto;	
	primeirofechado = (typeof(primeirofechado)=="undefined")?true:primeirofechado;
	$('#HintDestaque').css('animationIterationCount','infinite');
	
	var subtelas = $(".collapse h3").length;
	
	$(".collapse").accordion({
		active:false,collapsible:primeirofechado,
		heightStyle:"content", //Controla se a altura vai se de acordo com o conteúdo ou fixa
		
		classes: { //Esse classes te permite adicionar classes suas a cada elemento, sem elas o padrão são bordas arredondadas
		"ui-accordion-header":"BoxVermelhoAtivo boxAutopxMenor",
		"ui-accordion-header-collapsed":"BoxVermelho",
		"ui-accordion-content":"BoxCinzaClaro"},
		
		activate:function(event,ui){ //Libera tela ao clicar em todos						
			$(ui.newHeader).addClass('clicado');
			if($(ui.newPanel).find('audio.sominterno').length>0){
				stopPlay($(ui.newPanel).find('audio.sominterno'));
			}
			
			//var audioAtual = $('audio.sominterno:eq('+num+')');
			if(subtelas==$(".ui-accordion h3.clicado").length){
				$('#btproximo').removeClass('desabilitado').fadeIn(); 
				$('#HintDestaque').css('animationIterationCount','0');
			}
		}
	});
	
	if(!primeirofechado){ $(".collapse h3:first-child").addClass('clicado'); }
}

function interacao_carrossel(){
	$('#HintDestaque').css('animationIterationCount','infinite');
	
	$(".abas").tabs({ 
		heightStyle:"content", //Controla se a altura vai se de acordo com o conteúdo ou fixa [opções: "content"/"fill"]
		show:{effect:"slideDown",duration:500},//Troque o efeito para fadeIn e fadeOut se quiser
		hide:{effect:"slideUp",duration:500},//Troque o efeito para fadeIn e fadeOut se quiser
		
		classes:{ //Esse classes te permite adicionar classes suas a cada elemento, sem elas o padrão são bordas arredondadas
		  "ui-tabs":"BoxCinzaClaro",
		  "ui-tabs-nav":"navegacaoAbas",
		  "ui-tabs-tab":"",
		  "ui-tabs-panel":""
		},
		
		activate:function(event,ui){ //Libera tela ao clicar em todos
			$(ui.newTab).addClass('clicado');
			stopPlay($(ui.newPanel).find('audio.sominterno'));
			if($(".abas .navegacaoAbas li").length==$(".abas .navegacaoAbas li.clicado").length){
				$('#btproximo').removeClass('desabilitado').fadeIn(); 
				$('#HintDestaque').css('animationIterationCount','0');
			}
		}
	});
	
	$(".abas .navegacaoAbas li:first-child").addClass('clicado');	
}




/*
		activate:function(event,ui){ //Libera tela ao clicar em todos						
			$(ui.newHeader).addClass('clicado');
			if($(ui.newPanel).find('audio.sominterno').length>0){
				stopPlay($(ui.newPanel).find('audio.sominterno'));
			}
			
			//var audioAtual = $('audio.sominterno:eq('+num+')');
			if(subtelas==$(".ui-accordion h3.clicado").length){
				$('#btproximo').removeClass('desabilitado').fadeIn(); 
				$('#HintDestaque').css('animationIterationCount','0');
			}
		}
*/


function telaCheia(ele){
	if (ele.requestFullscreen) {
		ele.requestFullscreen();
	} else if (ele.webkitRequestFullscreen) {
		ele.webkitRequestFullscreen();
	} else if (ele.mozRequestFullScreen) {
		ele.mozRequestFullScreen();
	} else if (ele.msRequestFullscreen) {
		ele.msRequestFullscreen();
	} else {
		console.log('Fullscreen API não suportada.');
	}
}




function atualizaTela(num){
	//Pular telas com classe ignorar
	if(arrTela[num-1].conteudo.className.indexOf('ignorar')>-1){
		var res = (telaAtual<num)?num+1:num-1;
		atualizaTela(res);
		return;
	}
	
	telaAtual = num;
	if(telaAtual<1){ telaAtual=1; return; }
	if(telaAtual>arrTela.length){ telaAtual=arrTela.length; return; }
	$('#btanterior,#btproximo').addClass('desabilitado').stop().clearQueue();
    $('html,body').scrollTop(0);  //SETA A TELA NO TOPO QUANDO HOVER UMA ROLAGEM ANTERIOR.
	
	telaLiberada = (telaLiberada<telaAtual)?telaAtual:telaLiberada;
	
	//Menu
	$('#menu #atual').html((telaAtual<10)?'0'+telaAtual:telaAtual);
	$('#topo h3').html(arrTela[telaAtual-1].titulo);	
	$('.ui-dialog').remove();
	
	//Conteúdo
	$('.ui-dialog').remove();
	$('body')[0].className = 'tela'+telaAtual+( (arrTela[telaAtual-1].conteudo.className)?' '+arrTela[telaAtual-1].conteudo.className:'' );
	$('#conteudo').html(arrTela[telaAtual-1].conteudo);
	
	$('body').trigger('mudatela');
	}

var cache; 
$.get('cache.txt',function(data){ 
	cache = data.split('\n');
	cache.forEach(function(v,i){
		var ext = v.trim().split('.').pop();
		if(ext=='jpg' || ext=='jpeg' || ext=='png' || ext=='svg' || ext=='gif'){ cache[i] = 'img/'+v.trim(); }
		if(ext=='otf' || ext=='ttf' || ext=='eot' || ext=='woff' || ext=='woff2'){ cache[i] = 'fonts/'+v.trim(); }
		if(ext=='mp3'){ cache[i] = 'audio/'+v; }
		if(ext=='css'){ cache[i] = 'css/'+v; }
		if(ext=='js'){ cache[i] = 'js/'+v; }
	});
});

var queue = new createjs.LoadQueue();
//queue.installPlugin(createjs.Sound);
queue.on("progress",cacheProgresso,this);
queue.on("complete",cacheCompleto,this);

function cacheProgresso(e){ 
	var pct = Math.floor(e.progress*100);
	$('#btiniciar').html('<progress value="'+pct+'" max="100"></progress><br>'+pct+'% LOADING'); 
}

function cacheCompleto(){
	console.log('Cache carregado!');
	$('#btiniciar').html((telaAtual>2)?'CONTINUE':'START').prop("disabled",false).click(function(){ 
		atualizaTela((telaAtual<2)?2:telaAtual);
		telaCheia(document.documentElement);
	});
	
	$('#menumobile').click(function(){ $('nav#menu ul').toggle(); });
	
	$('#btmenu').click(function(){ 
		janelaModal('Menu','centro','auto','<div>'+strMenu+'</div>');
		$('#menucurso li').each(function(i,v){ if(telaLiberada>=v.dataset.tela){v.className = ''; } });	
	});
	$(document).on('click','#menucurso li',function(){ if(telaLiberada>=$(this).data('tela')){ atualizaTela($(this).data('tela')); } });
	
	$('#btajuda').click(function(){
		janelaModal('HELP','centro','fundo02 popupajuda',arrTela[1].conteudo.innerHTML);
		AOS.init({easing:'ease-in-out-sine'});
	});	
	
	$(document).on('click tap touch','.ui-widget-overlay',function(){ popupDialog.dialog('close'); });
}

function iniciaCurso(){	
	var carregado = $('#carregando').load('conteudo.html',function(){
		$(carregado).find('article').each(function(i,v){ arrTela[i].conteudo = v; });
		$('#carregando').remove();
		
		atualizaTela(1);
		telaAtual = 1;
		
		//Carrega Cache
		queue.loadManifest(cache);
		console.log('Conteúdo carregado!');
	});
}


$(function(){
	//Versão sem SCORM
	iniciaCurso();
	
	$('#btanterior').click(function(){
		if($(this).hasClass('desabilitado')){
			janelaModal('Oops!','centro','auto','<div><p>You still have contents for being accessed on this screen!</p></div>');
		} else {
			atualizaTela(telaAtual-1);
		}
	});
	$('#btproximo').click(function(){
		if($(this).hasClass('desabilitado')){
			janelaModal('Oops!','centro','auto','<div><p>You still have contents for being accessed on this screen!</p></div>');
		} else {
			atualizaTela(telaAtual+1); 
		}
	});
	
	/*$(document).on("keyup",function(e){
		if(e.which==37){ $('#btanterior').trigger('click'); }
		if(e.which==39){ $('#btproximo').trigger('click'); }
	});*/
	
});
