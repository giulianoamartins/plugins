var telaAtual = 1;
var arrTela = [
	{titulo:'Introduction'},
	{titulo:'Help'},
	{titulo:'Introduction',menu:'capitulo1'},
	{titulo:'Introduction',menu:'capitulo1'},
	{titulo:'Introduction',menu:'capitulo1'},
	{titulo:'Introduction',menu:'capitulo1'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Collaborators',menu:'capitulo2'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Agents',menu:'capitulo3'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Conduct in Relationship with Public Authorities',menu:'capitulo4'},
	{titulo:'Confidential information and safety of information',menu:'capitulo5'},
	{titulo:'Confidential information and safety of information',menu:'capitulo5'},
	{titulo:'Confidential information and safety of information',menu:'capitulo5'},
	{titulo:'Intellectual Property',menu:'capitulo6'},
	{titulo:'Intellectual Property',menu:'capitulo6'},
	{titulo:'Intellectual Property',menu:'capitulo6'},
	{titulo:'Intellectual Property',menu:'capitulo6'},
	{titulo:'Usiminas Companies Patrimony',menu:'capitulo7'},
	{titulo:'Usiminas Companies Patrimony',menu:'capitulo7'},
	{titulo:'Usiminas Companies Patrimony',menu:'capitulo7'},
	{titulo:'Usiminas Companies Patrimony',menu:'capitulo7'},
	{titulo:'Usiminas Companies Patrimony',menu:'capitulo7'},
	{titulo:'Integrity, Control and Monitoring Structure',menu:'capitulo8'},
	{titulo:'Integrity, Control and Monitoring Structure',menu:'capitulo8'},
	{titulo:'Communication Channels',menu:'capitulo9'},
	{titulo:'Communication Channels',menu:'capitulo9'},
	{titulo:'Communication Channels',menu:'capitulo9'},
	{titulo:'Discipline and Remediation',menu:'capitulo10'},
	{titulo:'Discipline and Remediation',menu:'capitulo10'},
	{titulo:'Other Important Informations',menu:'capitulo11'},
	{titulo:'Other Important Informations',menu:'capitulo11'},	
	{titulo:'Course Completion',menu:'capitulo12'}
	];

function tempoLeitura(){
	var tamanho = arrTela[telaAtual-1].conteudo.innerText.length
	tamanho = (tamanho<100)?100:tamanho;
	
	//Diminua o tempo de leitura alterando o multiplicador (Padrão:25)
	return tamanho*1;
}

//Chamada: anima_audio(); //Chamando assim toca o primeiro audio e libera a tela, para não desbloquear veja abaixo.
//Chamada: anima_audio(0,false); //Toca o primeiro audio da tela,true = libera tela ao final, false = não libera
function anima_audio(num,libera){
	if(typeof(num)=="undefined"){
	$('audio.som').parent().hide(1);
	num = 0;
	}
	libera = (typeof(libera)=="undefined")?true:libera;
	var audioAtual = $('audio.som:eq('+num+')');
	try{
	//Animacao da tag Pai (por isso colocar a tag <audio> como primeiro elemento)
	audioAtual.parent().fadeIn(1000);
	
	if(!isNaN(audioAtual[0].duration)){ 
	audioAtual[0].currentTime = 0;
	audioAtual[0].play();
	audioAtual[0].onended = function(){
	if(libera){
	$('#btproximo').delay(1000).removeClass('desabilitado').fadeIn();
	}
	if($('audio.som:eq('+(num+1)+')').length>0){ anima_audio(num+1,libera);}
	};
	}
	} catch(e){
	console.log('Audio: '+e);
	}
}


function libera_timer(tempo){
	tempo = (typeof(tempo)=="undefined")?tempoLeitura():tempo;
	$('#btproximo').addClass('desabilitado').animate({opacity:1},tempo,function(){ $(this).removeClass('desabilitado'); });
}


$(document).on('mudatela','body',function(){
	window.location = '#';
	AOS.init({easing:'ease-in-out-sine'});	
	$('#btanterior').addClass('desabilitado').stop().clearQueue();
	$('#btproximo').addClass('desabilitado').stop().clearQueue().fadeIn(1);
	
	//Programação por Tela
	switch(telaAtual){
		case 1:
			$('#btproximo').addClass('desabilitado').hide();
		break;

		case 9: 
			libera_timer(50000);
		break;
		
		case 10: 
			$('#P1_A').click(function(){ 
				janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>This choice shows that your vision is respectful to the colleague who has been in an embarrassing situation. Empathy is a sign that you understand the feelings of others. And if you feel comfortable doing this, you should report it.</p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P1_B').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>All collaborators must act in an honest, fair, dignified, courteous way, with availability and attention to all people with whom they relate, whether in the scope of work or as a result of it, both inside and outside Usiminas companies. If you witness or find out about a situation like this one, report it!</p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 	
		
		case 17: 
			libera_timer(25000);
		break;		
		
		
		case 18: 
			$('#P2_A').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>Think carefully! Access more information about conflicts of interest that are in the Conflicts of Interest and Related Party Transactions Policy. Good studies!</p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P2_B').click(function(){ 
				janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>Nice answer! More information about conflicts of interest can be found in the Conflicts of Interest and Related Party Transactions Policy. Good studies! </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 		
		
		case 20: 
			$('#Importante17').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>More detailed information on hiring and managing third party intermediaries is provided in the Relationship with Policy Relationship with Agents.</p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break;	
				
				
		case 23: 
			libera_timer(29000);
		break;	
		
						
		case 24: 
			$('#P3_A').click(function(){ 
					janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>Do you want to know more about it? For any situation involving offering, promising or receiving gifts, presents and hospitality, please check the Gifts and Hospitality Policy in advance. </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P3_B').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>Think about your attitude! And for any situation involving offering, promising or receiving gifts, presents and hospitality, please check the Gifts and Hospitality Policy in advance. </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 	
		
		case 26: 
			$('#Importante26A').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>More detailed information about donations and sponsorships is provided in the Sponsorship and Donations Policy.</p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#Importante26B').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>More detailed information about donations and sponsorships is provided in the Sponsorship and Donations Policy.</p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break;			
		
		case 27: 
			libera_timer(33000);
		break;		
		
		case 28: 
			$('#P4_A').click(function(){ 
				janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>Nice answer! Do you want to know more about donations and sponsorships? Then read the Sponsorship and Donations Policy.</p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P4_B').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>For this question, the correct answer is to suggest to the requester to read the Sponsorship and Donations Policy, and if in doubt, you can contact the Usiminas Institute.</p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 	
		

						
		case 34: 
			libera_timer(27000);
		break;		
				
		case 35: 
			$('#P5_A').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>Responsible use of the name and brands of Usiminas companies in social networks is a duty of all collaborators. In the same way, the use of such networks for personal purposes during the work time must always be guided by common sense and in accordance with the Code of Ethics and Conduct. </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P5_B').click(function(){ 
				janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>Good choice! Responsible use of the name and brands of Usiminas companies in social networks is a duty of all collaborators. In the same way, the use of such networks for personal purposes during the work time must always be guided by common sense and in accordance with the Code of Ethics and Conduct. </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 	
		


		case 38: 
			$('#Importante38').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p> If you have questions about how to behave in front of a public agent, contact your superior or the Integrity Department before taking or agreeing to any action. More detailed information on the relationship with Public Authorities is described in the Anti-Corruption Policy, available on the Intranet. </p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break;			
		
		case 40: 
			$('#Importante40').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>More detailed information about the relationship with Public Authorities is described in the Anti-Corruption Policy, available on the Intranet. </p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
					
			interacao_carrossel();
		break;	
		
		case 41: 
			interacao_carrossel();
		break;	
		
		case 42: 
			$('#Importante42').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>Resources, spaces, names and brands of Usiminas companies cannot be used to serve political or other interests other than those of Usiminas companies. </p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break;	
						
		case 48: 
			libera_timer(34000);
		break;			
		
		case 49: 
			$('#P6_A').click(function(){ 
				janelaModal('That’s right!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/correto.png" /></div><div class="col col-80 interna"><p>Good choice! For more information, access the Intellectual Property Standard, available on the Intranet. Good studies! </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
			
			$('#P6_B').click(function(){ 
				janelaModal('Oops!','centro','medio','<div class="row externa"><div class="col col-20 interna"> <img class="img-fluid center-block" src="img/errado.png" /></div><div class="col col-80 interna"><p>If you still have doubts about this topic, access the Intellectual Property Standard, available on the Intranet. Good studies! </p></div></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break; 	
		
		case 52: 
			$('#Importante52').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>All devices and systems of Usiminas companies, including corporate e-mails, are working instruments belonging to Usiminas companies.</p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});
		break;	
		
		
		case 56: 
			$('#pop55A').click(function(){ 
				janelaModal('Audit Committee','centro','medio','<div><p> It advises Usiminas Board of Directors in the inspection of the actions of the Integrity Department and the Conduct Committee. It ensures correct implementation and compliance with this Code and the other policies of the Integrity Program. </p></div>',0,function(){ 
				});
			});
			
			$('#pop55B').click(function(){ 
				janelaModal('Integrity Department','centro','medio','<div><p>It is responsible for implementing, reviewing and updating the actions that take part on Integrity Program. Among its functions, it manages the Open Channel and the investigation of complaints received by it. </p></div>',0,function(){ 
				});
			});
			
			$('#pop55C').click(function(){ 
				janelaModal('Conduct Comitee','centro','medio','<div><p>Responsible for implementing actions related to violations of this Code and the policies of the Integrity Program, as well as for determining the appropriate disciplinary and/or remedial measures and actions.</p></div>',0,function(){ 
				});
			});	
			

			
			/* LIBERA TELA APENAS NO MOBILE */
			function myFunction(x) {
			  if (x.matches) { // If media query matches
				$('#btproximo').removeClass('desabilitado').fadeIn(); 
			  } 
			}
			
			var x = window.matchMedia("(max-width: 1023px)")
			myFunction(x) // Call listener function at run time
			x.addListener(myFunction) // Attach listener function on state changes		
			/* FIM LIBERA TELA APENAS NO MOBILE */
		break;			
		

		case 61: 
			$('#Importante60').click(function(){ 
				janelaModal('IMPORTANT!','centro','medio','<div><p>Regardless of these measures, Usiminas may take necessary actions to interrupt detected irregularities or violations of integrity.</p></div>',0,function(){ 
					$('#btproximo').removeClass('desabilitado').fadeIn(); 
				});
			});		
		break;												
		
		case 64: //Tela Final
			$('#btproximo').addClass('desabilitado').hide();
		break; 
										
		default: //Condições padrões das telas
			$('#btproximo').delay(tempoLeitura()).removeClass('desabilitado').fadeIn();
		break;		
	}
	
	
	//Regras dos botões de navegação
	if(telaAtual<telaLiberada){ $('#btproximo').removeClass('desabilitado').show(); }
	(telaAtual>2)?$('#btanterior').removeClass('desabilitado').fadeIn():$('#btanterior').addClass('desabilitado').fadeOut();
	if(telaAtual>=arrTela.length){ $('#btproximo').addClass('desabilitado'); }	
	if(telaAtual<2){ $('#btanterior').addClass('desabilitado').hide(); $('#btproximo').addClass('desabilitado'); }
});


/* IMPORTANTE TELA 40 APARECE 
$(document).on('click','.bt',function(e){
	$(e.target).addClass('clicado');
	if($('.bt002').hasClass('clicado') && $('.bt003').hasClass('clicado') && $('.bt004').hasClass('clicado')){ alert("lll")  }}
	);
 FIM IMPORTANTE TELA 40 APARECE */


    $(document).on('mouseover','.bt',function(e){
	$(e.target).addClass('clicado');
	if($('.bt1').hasClass('clicado') && $('.bt2').hasClass('clicado') && $('.bt3').hasClass('clicado') && $('.bt4').hasClass('clicado') && $('.bt5').hasClass('clicado') && $('.bt6').hasClass('clicado') && $('.bt8').hasClass('clicado') && $('.bt7').hasClass('clicado')){ $('#btproximo').removeClass('desabilitado').fadeIn();  }
	});




function AlternativasAMouseOver(){document.getElementById('configLetrasPerguntaA').style.backgroundColor = "#009ED5";}
function AlternativasAMouseOut(){document.getElementById('configLetrasPerguntaA').style.backgroundColor = "#982A7C";}

function AlternativasBMouseOver(){document.getElementById('configLetrasPerguntaB').style.backgroundColor = "#009ED5";}
function AlternativasBMouseOut(){document.getElementById('configLetrasPerguntaB').style.backgroundColor = "#982A7C";}








$(document).on('click','.bt',function(e){
	$(e.target).addClass('clicado');
	if($('.bt01').hasClass('clicado') && $('.bt02').hasClass('clicado') && $('.bt03').hasClass('clicado')){ $('#btproximo').removeClass('desabilitado').fadeIn();  }
	});
	
function TrocaIMG55A﻿() {
    document.getElementById(﻿'pop55A').src = "img/Tela55HintA_Visited.png"
}	

function TrocaIMG55B﻿() {
    document.getElementById(﻿'pop55B').src = "img/Tela55HintB_Visited.png"
}	

function TrocaIMG55C﻿() {
    document.getElementById(﻿'pop55C').src = "img/Tela55HintC_Visited.png"
}	

